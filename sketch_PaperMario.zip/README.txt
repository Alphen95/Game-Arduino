Paper Mario World v1.1

Changelog:
Added : 
map with music

Removed:
-none-